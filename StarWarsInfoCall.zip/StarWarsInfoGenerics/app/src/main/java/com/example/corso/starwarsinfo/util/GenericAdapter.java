package com.example.corso.starwarsinfo.util;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.corso.starwarsinfo.R;
import com.example.corso.starwarsinfo.data.Person;
import com.example.corso.starwarsinfo.data.Planet;
import com.example.corso.starwarsinfo.data.Starship;

import java.util.List;

public class GenericAdapter<T extends GenericData> extends BaseAdapter {

    ItemSelectedCallback mCallback;
    private List<T> dataSet;
    private Context mContext;

    public GenericAdapter(Context context, List<? extends GenericData> dataSet, ItemSelectedCallback mCallback) {
        this.mContext = context;
        this.dataSet = (List<T>) dataSet;
        this.mCallback=mCallback;
    }

    @Override
    public int getCount() {
        if (dataSet != null) {
            return dataSet.size();
        }
        return 0;
    }

    @Override
    public T getItem(int position) {
        if (dataSet != null) {
            return dataSet.get(position);
        }
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        View view = LayoutInflater.from(mContext).inflate(R.layout.riga_item, null);

        T data = getItem(position);
        if (data != null) {
            ((TextView) view.findViewById(R.id.text_riga_item)).setText(data.getName());
        }

        LinearLayout rigaPeople = (LinearLayout) view.findViewById(R.id.riga_item);
        rigaPeople.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("OnClickPlanets", "Sono dentro");
                if(getItem(position) instanceof Person) {
                    mCallback.onPersonClicked(position, (Person) getItem(position));
                }else if (getItem(position) instanceof Planet) {
                    mCallback.onPlanetClicked(position, (Planet) getItem(position));
                }else
                    mCallback.onStarshipClicked(position, (Starship) getItem(position));
            }
        });

        return view;
    }
}

