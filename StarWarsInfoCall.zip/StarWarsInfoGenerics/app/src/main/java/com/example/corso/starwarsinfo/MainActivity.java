package com.example.corso.starwarsinfo;

import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.corso.starwarsinfo.data.Person;
import com.example.corso.starwarsinfo.data.Planet;
import com.example.corso.starwarsinfo.data.Starship;
import com.example.corso.starwarsinfo.fragment.PeopleFragment;
import com.example.corso.starwarsinfo.fragment.PersonDetailFragment;
import com.example.corso.starwarsinfo.fragment.PlanetDetailFragment;
import com.example.corso.starwarsinfo.fragment.PlanetsFragment;
import com.example.corso.starwarsinfo.fragment.StarshipDetailFragment;
import com.example.corso.starwarsinfo.fragment.StarshipsFragment;
import com.example.corso.starwarsinfo.presenters.PeoplePresenter;
import com.example.corso.starwarsinfo.presenters.PlanetsPresenter;
import com.example.corso.starwarsinfo.presenters.StarshipsPresenter;
import com.example.corso.starwarsinfo.util.ContractActivityFragment;

public class MainActivity extends AppCompatActivity implements ContractActivityFragment.View{

    ContractActivityFragment.Presenter activityToFragment;
    TextView peopleText;
    TextView planetsText;
    TextView starshipsText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        peopleText = (TextView) findViewById(R.id.people_text);
        planetsText = (TextView) findViewById(R.id.planets_text);
        starshipsText = (TextView) findViewById(R.id.starships_text);

            peopleText.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    PeopleFragment f = new PeopleFragment();
                        new PeoplePresenter(f);
                        getSupportFragmentManager().beginTransaction()
                                .add(R.id.container, f).addToBackStack(null).commit();
                }

            });

        planetsText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                PlanetsFragment f = new PlanetsFragment();
                new PlanetsPresenter(f);
                getSupportFragmentManager().beginTransaction()
                        .add(R.id.container, f).addToBackStack(null).commit();
            }

        });

        starshipsText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                StarshipsFragment f = new StarshipsFragment();
                new StarshipsPresenter(f);
                getSupportFragmentManager().beginTransaction()
                        .add(R.id.container, f).addToBackStack(null).commit();
            }

        });



    }

    @Override
    public void onPersonSelected(int position, Person person) {

        PersonDetailFragment newFragment = PersonDetailFragment.newInstance(person);
            /*Bundle args = new Bundle();
            args.putInt(PersonDetailFragment.ARG_POSITION, position);
            newFragment.setArguments(args);*/

            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

            // Replace whatever is in the fragment_container view with this fragment,
            // and add the transaction to the back stack so the user can navigate back
            transaction.replace(R.id.container, newFragment).addToBackStack(null);
            // Commit the transaction
            transaction.commit();

    }

    @Override
    public void onPlanetSelected(int position, Planet planet) {

        PlanetDetailFragment newFragment = PlanetDetailFragment.newInstance(planet);
            /*Bundle args = new Bundle();
            args.putInt(PersonDetailFragment.ARG_POSITION, position);
            newFragment.setArguments(args);*/

        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

        // Replace whatever is in the fragment_container view with this fragment,
        // and add the transaction to the back stack so the user can navigate back
        transaction.replace(R.id.container, newFragment).addToBackStack(null);
        // Commit the transaction
        transaction.commit();

    }

    @Override
    public void onStarshipSelected(int position, Starship starship) {

        StarshipDetailFragment newFragment = StarshipDetailFragment.newInstance(starship);
            /*Bundle args = new Bundle();
            args.putInt(PersonDetailFragment.ARG_POSITION, position);
            newFragment.setArguments(args);*/

        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

        // Replace whatever is in the fragment_container view with this fragment,
        // and add the transaction to the back stack so the user can navigate back
        transaction.replace(R.id.container, newFragment).addToBackStack(null);
        // Commit the transaction
        transaction.commit();

    }
}
