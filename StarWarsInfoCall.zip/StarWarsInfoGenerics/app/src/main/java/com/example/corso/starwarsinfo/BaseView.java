package com.example.corso.starwarsinfo;

public interface BaseView<T> {

    void setPresenter(T presenter);

}
