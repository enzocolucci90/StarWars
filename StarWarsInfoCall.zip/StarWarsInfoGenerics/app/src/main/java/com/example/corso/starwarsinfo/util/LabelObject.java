package com.example.corso.starwarsinfo.util;

public interface LabelObject {

    public void getName();

}
