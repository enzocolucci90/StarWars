package com.example.corso.starwarsinfo.fragment;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.example.corso.starwarsinfo.R;
import com.example.corso.starwarsinfo.contracts.PlanetsContract;
import com.example.corso.starwarsinfo.data.Person;
import com.example.corso.starwarsinfo.data.Planet;
import com.example.corso.starwarsinfo.data.Starship;
import com.example.corso.starwarsinfo.util.ContractActivityFragment;
import com.example.corso.starwarsinfo.util.GenericAdapter;
import com.example.corso.starwarsinfo.util.ItemSelectedCallback;

import java.util.List;

public class PlanetsFragment extends Fragment implements PlanetsContract.View,ItemSelectedCallback {


    PlanetsContract.Presenter PlanetsPresenter;
    ContractActivityFragment.View mCallback;
    ListView itemList;

    public PlanetsFragment() {    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState)
    {
        PlanetsPresenter.getAllPlanets();

        View rootView = inflater.inflate(R.layout.fragment_item, container, false);
        itemList = (ListView) rootView.findViewById(R.id.item_list);
        return rootView;

    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mCallback = (ContractActivityFragment.View) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString());
        }
    }

    @Override
    public void setPresenter(PlanetsContract.Presenter presenter) {

        PlanetsPresenter = presenter;

    }

    @Override
    public void presenterToFragment(List<Planet> listaPlanet) {

        GenericAdapter adapter=new GenericAdapter(getActivity(), listaPlanet, this);
        itemList.setAdapter(adapter);
    }

    @Override
    public void onPersonClicked(int position, Person person) {

    }

    @Override
    public void onPlanetClicked(int position, Planet planet) {
        mCallback.onPlanetSelected(position,planet);
    }

    @Override
    public void onStarshipClicked(int position, Starship starship) {

    }
}
