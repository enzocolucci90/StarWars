package com.example.corso.starwarsinfo.util;

public abstract class GenericData {

    public abstract String getName();

}
