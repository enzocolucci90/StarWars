package com.example.corso.starwarsinfo;

public interface BasePresenter {

    void start();

}
